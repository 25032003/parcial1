module com.example.parcialprogra1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.parcialprogra1 to javafx.fxml;
    exports com.example.parcialprogra1;
}